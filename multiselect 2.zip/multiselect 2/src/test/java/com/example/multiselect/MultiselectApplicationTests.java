package com.example.multiselect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiselectApplicationTests {

	@Test
	void contextLoads() {
	}

}
