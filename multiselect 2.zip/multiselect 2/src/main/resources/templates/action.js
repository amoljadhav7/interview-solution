$(document).ready(function() {
		  $('.go_in').click(function() {
		    return !$('.all_options option:selected').remove().appendTo('.chosen_options');
		});
		$('.go_out').click(function() {
		   return !$('.chosen_options option:selected').remove().appendTo('.all_options'); 
		});
		
		$('form').submit(function() {
		    $('.all_options option').prop('selected','');
		    $('.chosen_options option').prop('selected','selected');
		    alert($(this).serialize());
		});
});